#ifndef SURFSIDECIENCEENUMS_H
#define SURFSIDESCIENCE_H

typedef enum surfsidescienceenums{
    SUCCESS=1,
    ERROR=-1,
};
#endif